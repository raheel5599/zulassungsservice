# TARIQ Händlerportal – Designvorlagen

Acht unveränderte Bildentwürfe für das Händlerportal der TARIQ Zulassungsservice UG (haftungsbeschränkt). Nur die Dateinamen wurden zur Übersicht angepasst.

Die Bilder sind Designkonzepte (keine implementierten Funktionen). Die Beispieldaten sind fiktiv.

- `haendlerportal/vorlagen/01_Dashboard.png`
- `haendlerportal/vorlagen/02_Auftraege.png`
- `haendlerportal/vorlagen/03_Neuer_Auftrag.png`
- `haendlerportal/vorlagen/04_Auftragsdetails.png`
- `haendlerportal/vorlagen/05_Dokumente.png`
- `haendlerportal/vorlagen/06_Abholservice.png`
- `haendlerportal/vorlagen/07_Rechnungen.png`
- `haendlerportal/vorlagen/08_Einstellungen.png`
