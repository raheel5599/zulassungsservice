# TARIQ Zulassungsservice – Office-Portal Designvorlagen

10 Bildvorlagen für das interne Büro-/Office-Portal. Diese Dateien sind statische Designkonzepte, keine funktionierende Software.

GitHub-Zielordner: `office/vorlagen/`

- 01_Office_Dashboard.png
- 02_Auftragsverwaltung.png
- 03_Neuer_Auftrag.png
- 04_Kundenverwaltung.png
- 05_Dokumentenpruefung.png
- 06_Touren_Abholung.png
- 07_Rechnungen_Buchhaltung.png
- 08_Kennzeichenproduktion.png
- 09_Mitarbeiter_Rechte.png
- 10_Einstellungen.png
