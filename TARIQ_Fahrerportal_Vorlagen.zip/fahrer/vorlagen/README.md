# TARIQ Fahrerportal – Designvorlagen

Acht visuelle Entwürfe für das Fahrerportal der TARIQ Zulassungsservice UG (haftungsbeschränkt).

Zielpfad im GitHub-Repository: `fahrer/vorlagen/`.

Die Ansichten sind reine Designvorlagen, keine funktionierende Anwendung. Beispieladressen und -daten sind fiktiv.
